Height: Height of the participant in inches.
Weight: Weight of the participant in pounds.
Age: Age of the participant in years.
Grip strength: Grip strength of the participant in kilograms.
Frailty: Qualitative attribute indicating the presence or absence of frailty symptoms (Y/N).
Usage:
This raw data file can be used for various analyses and modeling tasks related to frailty among females.